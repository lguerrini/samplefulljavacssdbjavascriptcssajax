package vvv;

// Import Java.sql
import java.sql.*;
import java.util.ArrayList;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

public class DBConn {

    // Create a connection variable and set it to null
    final static String dbname = "classicmodels";
    Connection conn = null;

    public DBConn() {
        // Provide a try and catch exception
        try {
            // Connect to mysql library
            Class.forName("com.mysql.jdbc.Driver");
            // jdbc:mysql://hostname:port/databasename, server username, server password
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/" + dbname, "root", "");

        } catch (Exception ex) {
            // If connection fail
            System.out.println("Erro: " + ex);

        }
    }

    public String dbgetdataTable(String action, String data) throws SQLException {
        String dati = "";
        if (action.equals("view")) {
            ArrayList<String> fields = getFields(data);
            String htmlt = "";
            htmlt += "<tr>";
            for (int i=0;i<fields.size();i++) {
                // set value to jtable
                htmlt += "<th>" + fields.get(i) + "</th>";
            }
            htmlt += "</tr>";

            String sql = "SELECT * FROM " + data;
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                htmlt += "<tr>";
                for (int i = 0; i < fields.size(); i++) {
                    String valore = rs.getString(fields.get(i));
                    htmlt += "<td>" + valore + "</td>";
                }
                htmlt += "</tr>";
            }
            dati = "<table>" + htmlt + "</table>";
        }
        return dati;
    }

    private ArrayList<String> getFields(String data) throws SQLException{
        ArrayList<String> fields = new ArrayList<String>();
                String sql = "SELECT COLUMN_NAME  FROM INFORMATION_SCHEMA.COLUMNS  "
                    + "WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?;";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, dbname);
            stmt.setString(2, data);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                // set value to jtable
                String id = rs.getString("COLUMN_NAME");
                fields.add(id);
            }
            return fields;
    
    }
    
    public String dbgetdataTableJSON(String action, String data) throws SQLException {
        String dati = "";
        if (action.equals("view")) {
            ArrayList<String> fields = getFields(data);
        
            String sql = "SELECT * FROM "+data;
            PreparedStatement stmt = conn.prepareStatement(sql);
            
            ResultSet rs = stmt.executeQuery();
            JSONArray jArray = new JSONArray();
            while (rs.next()) {
                JSONObject jobj = new JSONObject();
                for (int i = 0; i < fields.size(); i++) {
                    String valore = rs.getString(fields.get(i));
                    jobj.put(fields.get(i), valore);
                }
                jArray.add(jobj);
            }
            
            JSONObject jObjDati = new JSONObject();
            jObjDati.put("datidb", jArray);
            jObjDati.put("id", fields.get(0));
            dati = jObjDati.toJSONString();
        }
        return dati;
    }

    public String dbgetdatalistavt() throws SQLException {
        String dati = "";
        DatabaseMetaData meta = (DatabaseMetaData) conn.getMetaData();
        ResultSet rs = meta.getTables(null, null, null, new String[]{"TABLE"});
        String htmlt = "";
        while (rs.next()) {
            htmlt += "<option value='" + rs.getString("TABLE_NAME") + "'>" + rs.getString("TABLE_NAME") + "</option>";
        }
        rs = meta.getTables(null, null, null, new String[]{"VIEW"});
        while (rs.next()) {
            htmlt += "<option value='" + rs.getString("TABLE_NAME") + "'>" + rs.getString("TABLE_NAME") + "</option>";
        }
        dati = "<select id='listavt'>" + htmlt + "</select>";
        return dati;
    }

    boolean insDato(String str) {
        boolean ok = true;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sval = "";
        String scon = "";
        // 2;123

        String[] parts = str.split(";"); //returns an array with the 2 parts
        if (parts.length == 2) {
            scon = parts[0].trim(); //14.015
            sval = parts[1].trim(); //14.015
        } else {
            return false;
        }
        // String sql = "INSERT INTO tbl_list(fname, lname, age) VALUES('"+fname+"','"+lname+"','"+age+"')";
        String sql = "INSERT INTO tbl_datiarduino(valore, cont) VALUES(?,?)";
        try {
            // set stmt to create statement
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, Integer.parseInt(sval));
            stmt.setInt(2, Integer.parseInt(scon));
// executeUpdate() function runs condition like InsertRecord, UpdateRecord, delete, drop etc
            // executeUpdate return 1 if true 0 if false
            if (stmt.executeUpdate() == 1) {
                ok = true;
            } else {
                ok = false;
            }

        } catch (Exception ex) {
            System.out.println("Error: " + ex);
        }
        return ok;
    }

}
