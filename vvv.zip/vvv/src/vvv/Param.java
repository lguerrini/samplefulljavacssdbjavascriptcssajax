/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vvv;

/**
 *
 * @author luca lorenzo guerrin
 */
public class Param {
   public String nome;
   public String valore;

    public Param(String nome, String valore) {
        this.nome = nome;
        this.valore = valore;
    }
    
}
