window.onload = function () {
    caricaListavt();

};

function caricaListavt() {
    fetch("/?act=listavt")
            .then(function (response) {
                return response.text();
            })
            .then(function (html) {
                mydiv = document.querySelector("#divlistavt");
                mydiv.innerHTML = html;

            })
            .then(function (ok) {
                let sel = document.querySelector("#listavt");
                sel.addEventListener("change", function () {
                    caricajson('listaj');
                });

                caricajson('listaj');

            })
            .catch(error => console.log("Si è verificato un errore!"))
}
function hiderespdiv() {
    divs = document.querySelectorAll(".respdiv");
    for (i = 0; i < divs.length; i++) {
        divs[i].style.display = "none";
    }
}
function carica(div) {
    hiderespdiv();
    let view = document.querySelector("#listavt").value;
    fetch("/?act=view&tbl=" + view + "&typ=table")
            .then(function (response) {
                return response.text();
            })
            .then(function (html) {
                mydiv = document.querySelector("#" + div);
                mydiv.innerHTML = html;
                mydiv.style.display = "block";
            })
            .catch(error => console.log("Si è verificato un errore!"))
}
function caricajson(div) {
    hiderespdiv();
    let view = document.querySelector("#listavt").value;
    fetch("/?act=view&tbl=" + view + "&typ=json")
            .then(function (response) {
                return response.json();
            })
            .then(function (json) {
                tx = JSON.stringify(json);
                keys = getKeys(json.datidb[0]);
                dati = json.datidb;
                table = prepTable(keys, dati);

                mydiv = document.querySelector("#" + div);
                mydiv.innerHTML = "<br>" + table + "<br><div style='max-width:50%;'>" + tx + "</div>";
                mydiv.style.display = "block";
            })
            .catch(error => console.log("Si è verificato un errore!"))
}

function prepTable(keys, dati) {
    table = "";
    htmlr = "<tr>";
    for (var k in keys) {
        htmlr += "<th>" + keys[k] + "</th>";
    }
    htmlr += "</tr>";
    for (r in dati) {
        htmlr += "<tr>";
        row = dati[r];
        for (field in row) {
            htmlr += "<td>" + row[field] + "</td>";
        }
        htmlr += "</tr>";

    }

    table = "<table>" + htmlr + "</table>";
    return table;
}
function getKeys(json) {

    var keys = [];
    for (var k in json)
        keys.push(k);
    return keys;
}


